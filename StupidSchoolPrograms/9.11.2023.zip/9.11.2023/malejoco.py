# Zad. 4 Program wyświetlający liczby całkowite od 10 - -10 [malejąco.py]

for i in range(10, -11, -1):
    print(i)