# Zad. 3 Program wyświetlający w kolumnie liczby całkowite, nieparzyste 1 - 33 [rosnąco.py]

for i in range(1, 34):
    if i%2!=0:
        print(i)